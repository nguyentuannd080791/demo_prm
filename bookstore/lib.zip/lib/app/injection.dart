import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../core/network/api_client.dart';
import '../features/auth/data/datasources/auth_local_datasource.dart';
import '../features/auth/data/datasources/auth_remote_datasource.dart';
import '../features/auth/data/repositories/auth_repository_impl.dart';
import '../features/auth/presentation/providers/auth_provider.dart';

/// Composition root: the only place that knows concrete implementations.
class AppDependencies {
  AppDependencies._({required this.authProvider});

  final AuthProvider authProvider;

  static Future<AppDependencies> create() async {
    final prefs = await SharedPreferences.getInstance();
    final authLocal = AuthLocalDataSource(prefs);
    final apiClient = ApiClient(
      httpClient: http.Client(),
      readToken: authLocal.readToken,
    );
    final authRepository = AuthRepositoryImpl(
      AuthRemoteDataSource(apiClient),
      authLocal,
    );
    return AppDependencies._(authProvider: AuthProvider(authRepository));
  }
}
