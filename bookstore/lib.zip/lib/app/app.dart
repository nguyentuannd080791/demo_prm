import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../features/auth/presentation/pages/login_page.dart';
import '../features/auth/presentation/providers/auth_provider.dart';
import 'home_shell.dart';
import 'injection.dart';

class App extends StatelessWidget {
  const App({super.key, required this.dependencies});

  final AppDependencies dependencies;

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: dependencies.authProvider,
      child: MaterialApp(
        title: 'Book Store',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        ),
        home: const _AuthGate(),
      ),
    );
  }
}

class _AuthGate extends StatelessWidget {
  const _AuthGate();

  @override
  Widget build(BuildContext context) {
    final isAuthenticated =
        context.select<AuthProvider, bool>((auth) => auth.isAuthenticated);
    return isAuthenticated ? const HomeShell() : const LoginPage();
  }
}
