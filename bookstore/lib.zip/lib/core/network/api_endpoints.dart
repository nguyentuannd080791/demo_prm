class ApiEndpoints {
  static const baseUrl = 'http://localhost:8080';

  static const login = '/api/auth/login';
  static const register = '/api/auth/register';
}
